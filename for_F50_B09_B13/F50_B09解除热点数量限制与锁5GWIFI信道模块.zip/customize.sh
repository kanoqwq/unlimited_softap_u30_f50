#!/system/bin/sh
log_print() {
    echo "[`date '+%H:%M:%S'`] $1"
}
log_print "模块安装完成！，默认5GWIFI信道锁定值为36"
log_print "你可以创建/data/kano_ap_channel.cfg并填入你想要的信道"
log_print "重启即可锁定该信道（只建议36和149）"
