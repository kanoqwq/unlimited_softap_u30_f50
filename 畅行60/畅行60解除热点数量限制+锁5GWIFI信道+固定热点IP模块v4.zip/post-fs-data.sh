#!/system/bin/sh
# Magisk post-fs-data stage script
# Recursively bind-mount only files placed under:
#   apx/<apex_module>/<relative_path>
# to:
#   /apex/<apex_module>/<relative_path>
#   /apex/<apex_module>@*/<relative_path>

MODDIR=${0%/*}
SRC_ROOT="$MODDIR/apx"

logi() { echo "[apex-bind] $*" >/dev/kmsg; }
fail() { echo "[apex-bind][ERR] $*" >/dev/kmsg; }

do_bind_file() {
  src="$1"
  dst="$2"

  if [ ! -f "$src" ]; then
    fail "Source file missing: $src"
    return
  fi

  if [ ! -f "$dst" ]; then
    fail "Target file missing: $dst"
    return
  fi

  mount -o bind "$src" "$dst"
  if [ $? -eq 0 ]; then
    logi "Bind file ok: $src -> $dst"
  else
    fail "Bind file failed: $src -> $dst"
  fi
}

bind_one_file_to_apex_group() {
  mod_name="$1"
  src_file="$2"

  mod_src_root="$SRC_ROOT/$mod_name"
  rel="${src_file#$mod_src_root/}"

  base="/apex/$mod_name"

  do_bind_file "$src_file" "$base/$rel"

  for apex_dir in "$base"@*; do
    [ -d "$apex_dir" ] || continue
    do_bind_file "$src_file" "$apex_dir/$rel"
  done
}

bind_apex_group_files() {
  mod_name="$1"
  mod_src_root="$SRC_ROOT/$mod_name"

  if [ ! -d "$mod_src_root" ]; then
    fail "Source dir missing: $mod_src_root"
    return
  fi

  find "$mod_src_root" -type f | while read -r src_file; do
    bind_one_file_to_apex_group "$mod_name" "$src_file"
  done
}

if [ ! -d "$SRC_ROOT" ]; then
  fail "Source root not found: $SRC_ROOT"
  exit 1
fi

for mod_src in "$SRC_ROOT"/*; do
  [ -d "$mod_src" ] || continue
  mod_name="${mod_src##*/}"
  bind_apex_group_files "$mod_name"
done

exit 0