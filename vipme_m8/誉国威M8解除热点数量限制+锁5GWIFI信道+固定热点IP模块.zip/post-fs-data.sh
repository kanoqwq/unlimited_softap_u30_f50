#!/system/bin/sh
# Magisk post-fs-data stage script
# Bind-mount module apex dirs over /apex/<module> and all @ version dirs.
# New layout:
#   apx/com.android.wifi/...
#   apx/com.android.tethering/...

MODDIR=${0%/*}

SRC_ROOT="$MODDIR/apx"

logi() { echo "[apex-bind] $*" >/dev/kmsg; }
fail() { echo "[apex-bind][ERR] $*" >/dev/kmsg; }

do_bind_dir() {
  src="$1"
  dst="$2"

  if [ -d "$dst" ]; then
    mount -o bind "$src" "$dst"
    if [ $? -eq 0 ]; then
      logi "Bind ok: $src -> $dst"
    else
      fail "Bind failed: $src -> $dst"
    fi
  else
    fail "Target missing: $dst"
  fi
}

bind_apex_group() {
  mod_name="$1"
  src="$2"
  base="/apex/$mod_name"

  if [ ! -d "$src" ]; then
    fail "Source dir missing: $src"
    return
  fi

  do_bind_dir "$src" "$base"
  for dst in ${base}@*; do
    [ -d "$dst" ] || continue
    do_bind_dir "$src" "$dst"
  done
}

if [ ! -d "$SRC_ROOT" ]; then
  fail "Source root not found: $SRC_ROOT"
  exit 1
fi

for src in "$SRC_ROOT"/*; do
  [ -d "$src" ] || continue
  mod_name="${src##*/}"
  bind_apex_group "$mod_name" "$src"
done

exit 0
