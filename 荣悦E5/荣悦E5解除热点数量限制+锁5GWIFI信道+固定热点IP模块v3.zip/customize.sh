#!/system/bin/sh
log_print() {
    echo "[date '+%H:%M:%S'] $1"
}
log_print "正在卸载tethering服务的更新包"
cmd package uninstall-system-updates com.google.android.networkstack.tethering
log_print "模块安装完成！，默认5GWIFI信道锁定值为36"
log_print "你可以创建/data/kano_ap_channel.cfg并填入你想要的信道"
log_print "你可以创建/data/kano_softap_timeout设置热点无人连接自动超时时间，默认不自动关闭热点"
log_print "你可以创建/data/kano_is_hidden_ssid设置热点是否隐藏SSID，默认不隐藏"
log_print "重启即可锁定该信道（只建议36和149）"
log_print "热点网关:192.168.43.1  USB网络共享网关:192.168.42.1"